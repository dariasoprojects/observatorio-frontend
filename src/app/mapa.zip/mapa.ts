import '@arcgis/core/assets/esri/themes/light/main.css'; 


import  esriConfig  from '@arcgis/core/config';

import OAuthInfo from '@arcgis/core/identity/OAuthInfo';
import IdentityManager from '@arcgis/core/identity/IdentityManager';

import Basemap from "@arcgis/core/Basemap";
import Legend  from '@arcgis/core/widgets/Legend';
import Map from "@arcgis/core/Map";
import MapView from "@arcgis/core/views/MapView";
import GraphicsLayer from "@arcgis/core/layers/GraphicsLayer";
import MapImageLayer from "@arcgis/core/layers/MapImageLayer";
import Color from "@arcgis/core/Color";
import FeatureLayer from "@arcgis/core/layers/FeatureLayer";
import SimpleFillSymbol from "@arcgis/core/symbols/SimpleFillSymbol";

//simport { AuthService } from './auth.service';
import { HttpClientModule } from '@angular/common/http';

import Sketch from '@arcgis/core/widgets/Sketch';
import Polygon from '@arcgis/core/geometry/Polygon';
import Graphic from '@arcgis/core/Graphic';







export class Mapa {
  private mapView: MapView | null = null;
  private divId: string;
  private resultsLayer: GraphicsLayer | null = null;
  private simpleFillSymbol: SimpleFillSymbol | null = null;
  private capaMapServer: MapImageLayer | null = null;
  private rasterBosqueAmazonico: MapImageLayer | null = null;
  private rasterBosqueSeco: MapImageLayer | null = null;
  private legendContainer!: HTMLDivElement;
 
  constructor(divId: string) {
    this.divId = divId;
    this.resultsLayer = new GraphicsLayer();
  }


  setSubLayerVisibility(layer: MapImageLayer, visibleIds: number[]): void {
    layer.sublayers.forEach((sublayer) => {
      sublayer.visible = visibleIds.includes(sublayer.id);
    });
  }



  async iniciar(): Promise<string> {
    try {
      this.capaMapServer = new MapImageLayer({
        url: "https://gis.bosques.gob.pe/server/rest/services/Geobosques/serv_geobosques_bosque_perdida/MapServer/",
      });

      this.rasterBosqueAmazonico= new MapImageLayer({
        url: "https://gis.bosques.gob.pe/server/rest/services/Geobosques/serv_geobosques_bosque_perdida_raster/MapServer/",
      });
      
      const map = new Map({
        basemap: "hybrid",
        layers: [this.rasterBosqueAmazonico, this.capaMapServer, this.resultsLayer!],
      });

      this.mapView = new MapView({
        container: this.divId,
        map: map,
        center: [-75.015, -9.19],
        zoom: 4,
      });

      this.legendContainer = document.createElement('div');
      this.legendContainer.classList.add('esri-widget', 'esri-widget--panel');
      this.legendContainer.style.width = '250px';
      this.legendContainer.style.display = 'none'; // Oculta al inicio

      const legend = new Legend({
        view: this.mapView ,  // Asociamos el widget de leyenda con la vista del mapa
        container: this.legendContainer
      });

      this.mapView.ui.add(this.legendContainer, 'bottom-right');  // 'top-left' coloca la leyenda en la parte superior izquierda del mapa

      const legendToggleBtn = document.createElement('div');
      legendToggleBtn.className = 'esri-widget esri-widget--button esri-interactive';
      legendToggleBtn.innerHTML = '<span class="esri-icon-layer-list" title="Mostrar/Ocultar Leyenda"></span>';
      legendToggleBtn.style.margin = '5px';

      legendToggleBtn.onclick = () => {
        const isVisible = this.legendContainer.style.display !== 'none';
        this.legendContainer.style.display = isVisible ? 'none' : 'block';
      };

      this.mapView.ui.add(legendToggleBtn, 'top-right');      
      this.setModoMapa(1);

      console.log("Mapa inicializado");
      return Promise.resolve("Mapa cargado con éxito 2.0");
    } catch (error) {
      console.error("Error al cargar el mapa: ", error);
      return Promise.reject("Error al cargar el mapa");
    }
  }

  resetZoom(): void {
    if (this.mapView) {  // Comprobamos si mapView no es null ni undefined
        this.mapView.goTo({
            center: [-75.015, -9.19],  // Centro inicial
            zoom: 4                    // Nivel de zoom inicial
        });
    } else {
        console.error("mapView no está definido");
    }

    if (this.capaMapServer) {
      this.capaMapServer.sublayers.forEach((sublayer) => {
        sublayer.definitionExpression = ""; // limpia cualquier filtro
        sublayer.visible = true; // opcional: muestra todas las subcapas
      });
    }

    this.clearResultsLayer();


  }


  clearResultsLayer(): void {
      if (this.resultsLayer) {  // Comprobamos que resultsLayer no sea null ni undefined
          this.resultsLayer.removeAll();  // Elimina todos los gráficos del layer
      } else {
          console.error("resultsLayer no está definido");
      }
  }


  setModoMapa(mode: number) {
    
    console.log("setModoMapa");
    this.resetZoom();
    this.clearResultsLayer();

    switch (mode) {
      case 1: // x Limites        
        this.setVisibleLayers2(2,true);
        this.setVisibleLayers2(3,true);
        this.setVisibleLayers2(4,true);
        this.setVisibleLayers2(1,false);
        this.setVisibleLayers2(0,false);
        console.log("Modo Limites activado");
        break;
      case 2: // x Anp        
        this.setVisibleLayers2(2,false);
        this.setVisibleLayers2(3,false);
        this.setVisibleLayers2(4,false);
        this.setVisibleLayers2(1,true);
        this.setVisibleLayers2(0,false);
        console.log("Modo ANP activado");
        break;
      case 3:// x Za        
        this.setVisibleLayers2(2,false);
        this.setVisibleLayers2(3,false);
        this.setVisibleLayers2(4,false);
        this.setVisibleLayers2(1,false);
        this.setVisibleLayers2(0,true);
        console.log("Modo Z.A activado");
        break;
      default:
        console.log("Modo no válido");
    }
  }

  
  setVisibleLayers2(layerIndex: number, isVisible: boolean) {
    

    if (this.capaMapServer) {  // Verificar si this.capaMapServer no es null ni undefined
    this.capaMapServer.load().then(() => {
      const subcapas = this.capaMapServer!.sublayers;  // Acceder a las subcapas

      if (subcapas && subcapas.length > 0) {  // Asegurarnos de que las subcapas existan

        // Log de todas las subcapas para verificar el índice real
        subcapas.forEach((subcapa, index) => {
          console.log(`Índice ${index} - Subcapa: ${subcapa.title}`);
        });

        // Acceder a la subcapa con el índice proporcionado
        const subcapa = subcapas.getItemAt(layerIndex); // Puede que sea un LayerCollection
        if (subcapa) {
          // Cambiar la visibilidad de la subcapa
          subcapa.visible = isVisible;
          console.log(`Subcapa ${layerIndex} ${isVisible ? 'visible' : 'hidden'}`);
        } else {
          console.warn(`No se encontró la subcapa en el índice ${layerIndex}`);
        }
      } else {
        console.error("No se encontraron subcapas en la capa MapImageLayer.");
      }
    }).catch(error => {
      console.error("Error al cargar las subcapas:", error);
    });
    } else {
    console.error("capaMapServer no está inicializada.");
    }

  }

  setSubLayerFilters(layer: MapImageLayer, filters: { [sublayerId: number]: string }): void {
    layer.sublayers.forEach((sublayer) => {
      if (filters[sublayer.id] !== undefined) {
        sublayer.definitionExpression = filters[sublayer.id];
      } else {
        sublayer.definitionExpression = ""; // Sin filtro si no está en el objeto
      }
    });
  }



  async queryByZonaAmort(codigo: string): Promise<void> {
    const url = "https://gis.bosques.gob.pe/server/rest/services/Geobosques/serv_geobosques_bosque_perdida/MapServer/4";
    const whereClause = `cod_za = '${codigo}'`;
    const features = await this.queryFeatureLayer(url, whereClause);

    this.addResultsToMap(features);

    if (this.capaMapServer) {
      this.setSubLayerVisibility(this.capaMapServer, [4]);      
      this.setSubLayerFilters(this.capaMapServer, {
        4: `cod_za = '${codigo}'`       
      });
    }

  }
  

  async queryByAreaNatural(codigo: string): Promise<void> {
    const url = "https://gis.bosques.gob.pe/server/rest/services/Geobosques/serv_geobosques_bosque_perdida/MapServer/3";
    const whereClause = `cod_anp = '${codigo}'`;
    const features = await this.queryFeatureLayer(url, whereClause);

    this.addResultsToMap(features);

    if (this.capaMapServer) {
      this.setSubLayerVisibility(this.capaMapServer, [3]);      
      this.setSubLayerFilters(this.capaMapServer, {
        3: `cod_anp = '${codigo}'`       
      });
    }

  }


  async queryByDistrito(ubigeo: string): Promise<void> {
    const url = "https://gis.bosques.gob.pe/server/rest/services/Geobosques/serv_geobosques_bosque_perdida/MapServer/2";
    const whereClause = `ubigeo = '${ubigeo}'`;
    const features = await this.queryFeatureLayer(url, whereClause);

    this.addResultsToMap(features);
    if (this.capaMapServer) {
      this.setSubLayerVisibility(this.capaMapServer, [0,1,2]);
      const coddep = ubigeo.slice(0, 2); // solo los 2 primeros caracteres
      const codprov = ubigeo.slice(0, 4); // solo los 2 primeros caracteres
      console.log("coddep : ", coddep);
      console.log("codprov : ", codprov);

      this.setSubLayerFilters(this.capaMapServer, {
        0: `coddep = '${coddep}'`,
        1: `ubigeo_prov  = '${codprov}'`,
        2: `ubigeo  = '${ubigeo}'`       
      });
    }
  }

  async queryByProvincia(ubigeo: string): Promise<void> {
    const url = "https://gis.bosques.gob.pe/server/rest/services/Geobosques/serv_geobosques_bosque_perdida/MapServer/1";
    const whereClause = `ubigeo_prov = '${ubigeo}'`;
    const features = await this.queryFeatureLayer(url, whereClause);
    this.addResultsToMap(features);
    if (this.capaMapServer) {

      this.setSubLayerVisibility(this.capaMapServer, [0,1]);

      const coddep = ubigeo.slice(0, 2); // solo los 2 primeros caracteres
      console.log("coddep : ", coddep);

      this.setSubLayerFilters(this.capaMapServer, {
        0: `coddep = '${coddep}'`,
        1: `ubigeo_prov  = '${ubigeo}'`       
      });
    }

  }

  async queryByDepartamento(ubigeo: string): Promise<void> {
    const url = "https://gis.bosques.gob.pe/server/rest/services/Geobosques/serv_geobosques_bosque_perdida/MapServer/0";
    const whereClause = `coddep = '${ubigeo}'`;
    const features = await this.queryFeatureLayer(url, whereClause);

    this.addResultsToMap(features);

    //this.setSubLayerVisibility(this.capaMapServer, [0]); // Muestra solo las capas 0 y 2

    if (this.capaMapServer) {
      this.setSubLayerVisibility(this.capaMapServer, [0]);

      this.setSubLayerFilters(this.capaMapServer, {
        0: `coddep = '${ubigeo}'`       
      });
    }



  }

  private addResultsToMap(features: __esri.Graphic[]): void {
    if (!this.resultsLayer) {
      console.error("No se encontró la capa de resultados.");
      return;
    }
  
    this.resultsLayer.removeAll(); // Limpia los resultados anteriores
  
    // Define el símbolo utilizando SimpleFillSymbol
    const symbol = new SimpleFillSymbol({
      color: [0, 255, 255, 0], // Fondo semitransparente (marrón claro con opacidad 30%)
      outline: {
        color: [0, 255, 255], // Borde más luminoso (naranja claro con opacidad 80%)
        width: 3, // Ancho del borde
      },
    });
  
    // Asigna el símbolo a cada gráfico
    const updatedFeatures = features.map((feature) => {
      feature.symbol = symbol; // Asigna el símbolo creado
      return feature;
    });
  
    this.resultsLayer.addMany(updatedFeatures); // Agrega las nuevas geometrías al mapa
  
    if (features.length > 0 && this.mapView) {
      this.mapView.goTo(features); // Ajusta la vista al área de los resultados
    }
  }

  async queryFeatureLayer(layerUrl: string, whereClause: string) {
    const featureLayer = new FeatureLayer({
      url: layerUrl,
    });
  
    const query = featureLayer.createQuery();
    query.where = whereClause;
    query.outFields = ["*"];
    query.returnGeometry = true;
  
    try {
      const response = await featureLayer.queryFeatures(query);
      console.log("Consulta exitosa:", response.features);
      return response.features;
    } catch (error) {
      console.error("Error en la consulta:", error);
      throw error;
    }
  }

  zoomIn(): void {
    if (this.mapView) {
      this.mapView.zoom += 1;
      console.log("Zoom aumentado");
    } else {
      console.error("El mapa no ha sido inicializado aún.");
    }
  }

  /**
   * Limpia y destruye la vista del mapa para liberar recursos.
   */
  destruir(): void {
    if (this.mapView) {
      this.mapView.destroy();
      this.mapView = null;
      console.log("Mapa destruido");
    }
  }
}


export class MapaAlertas {
  private mapView: MapView | null = null;
  private divId: string;
  private resultsLayer: GraphicsLayer ;
  private simpleFillSymbol: SimpleFillSymbol | null = null;
  private capaMapServer: MapImageLayer | null = null;
  private rasterATD: MapImageLayer | null = null;
  private arrcatalogoLayer: any[] = [];
  private sketsch: Sketch | null = null;
  private featureServerAlerts: FeatureLayer| null = null;
  private legendContainer!: HTMLDivElement;

  // constructor( private authService: AuthService, divId: string) {
  //   this.divId = divId;
  //   this.resultsLayer = new GraphicsLayer();


  // }


  constructor(  divId: string) {



    this.divId = divId;
    this.resultsLayer = new GraphicsLayer();


  }


 // https://gis.bosques.gob.pe/server/rest/services/Geobosques/serv_geobosques_alertas_tempranas_areas_interes/MapServer/5


  async zoomElemento_Categoria(idcate: number, textvalue: string ): Promise<any[]> {

    const arrlayers =  this.getCatalogoById(idcate);    
    
    const whereClause = `UPPER(${arrlayers.campo_pk}) LIKE UPPER('%${textvalue}%')`;

    const urlsrv = arrlayers.url_servicio ;

    console.log("urlsrv", urlsrv);
    console.log("whereClause", whereClause);


    //const url = "https://gis.bosques.gob.pe/server/rest/services/Geobosques/serv_geobosques_bosque_perdida/MapServer/2";
    //const whereClause = `ubigeo = '${ubigeo}'`;
    
    const features = await this.queryFeatureLayer(urlsrv, whereClause);

    console.log("Result features", features);

    this.addResultsToMap(features);

    return [];
  } 
  


  async getInfoByCategoria(idcate: number, textvalue: string ): Promise<any[]> {

    const arrlayers =  this.getCatalogoById(idcate);    
    
    const whereClause = `UPPER(${arrlayers.campo_desc}) LIKE UPPER('%${textvalue}%')`;
        
    const features = await this.queryFeatureLayer(arrlayers.url_servicio, whereClause);

    const transformedFeatures = features.map(feature => {
      // Accede a los atributos del feature
      const attributes = feature.attributes;

      // Crear un nuevo objeto JSON con los datos relevantes
      return {
        id: attributes[arrlayers.campo_pk]  ,  // Suponiendo que hay un campo 'id'       
        descripcion: attributes[arrlayers.campo_desc]
                
      };
    });

    //console.log("transformedFeatures 2, ", transformedFeatures)
    return transformedFeatures;       
 
  }


  resetZoom(): void {
    if (this.mapView) {  // Comprobamos si mapView no es null ni undefined
        this.mapView.goTo({
            center: [-75.015, -9.19],  // Centro inicial
            zoom: 4                    // Nivel de zoom inicial
        });
    } else {
        console.error("mapView no está definido");
    }
  }



  getCatalogoById(id: number): any | undefined {
    return this.arrcatalogoLayer.find(catalogo => catalogo.id === id);
  }



  async obtenerCategoriasTerritoriales(): Promise<any[]> {
    const url = "https://gis.bosques.gob.pe/server/rest/services/Geobosques/serv_geobosques_alertas_tempranas_areas_interes/MapServer/22";
    const whereClause = `1=1`;
    const features = await this.queryFeatureLayer(url, whereClause);

    // Transformar los features a un formato más accesible
    const transformedFeatures = features.map(feature => {
      // Accede a los atributos del feature
      const attributes = feature.attributes;

      // Crear un nuevo objeto JSON con los datos relevantes
      return {
        id: attributes.id_capa  ,  // Suponiendo que hay un campo 'id'
        nombre: attributes.alias,  // Suponiendo que hay un campo 'nombre'
        descripcion: attributes.campo_desc,  // Suponiendo que hay un campo 'descripcion'
        campo_pk : attributes.campo_pk,
        tipo_campo_pk : attributes.tipo_campo_pk, 
        campo_desc : attributes.campo_desc,
        tipo_campo_desc :attributes.tipo_campo_desc ,
        url_servicio  : attributes.url_servicio

        // Agrega más atributos según lo que necesites
      };
    });

    // Retornar el array de objetos transformados
    this.arrcatalogoLayer = transformedFeatures;
    return transformedFeatures;
  }


  async iniciar(): Promise<string> {
    try {
      this.capaMapServer = new MapImageLayer({
        url: "https://gis.bosques.gob.pe/server/rest/services/Geobosques/serv_geobosques_bosque_perdida/MapServer",
        sublayers: [
          {
            id: 0,
            visible: true
          },
          {
            id: 1,
            visible: true
          },
          {
            id: 2,
            visible: true
          }

          // Las demás no se incluyen, por lo tanto no se muestran
        ]
      });


      this.rasterATD= new MapImageLayer({
        url: "https://gis.bosques.gob.pe/server/rest/services/Geobosques/serv_geobosques_alertas_tempranas_raster/MapServer",
      });

      const map = new Map({
        basemap: "hybrid",
        layers: [this.rasterATD, this.capaMapServer, this.resultsLayer!],
      });

      this.mapView = new MapView({
        container: this.divId,
        map: map,
        center: [-75.015, -9.19],
        zoom: 4,
      });


      // Contenedor personalizado para la leyenda
      this.legendContainer = document.createElement('div');
      this.legendContainer.classList.add('esri-widget', 'esri-widget--panel');
      this.legendContainer.style.width = '250px';
      this.legendContainer.style.display = 'none'; // Oculta al inicio
      

      // Crear el widget de leyenda
      const legend = new Legend({
        view: this.mapView ,  // Asociamos el widget de leyenda con la vista del mapa
        container: this.legendContainer
      });

      // Posicionar la leyenda en el lado izquierdo
      this.mapView.ui.add(this.legendContainer, 'bottom-right');  // 'top-left' coloca la leyenda en la parte superior izquierda del mapa


      // Botón personalizado para activar/desactivar la leyenda
      const legendToggleBtn = document.createElement('div');
      legendToggleBtn.className = 'esri-widget esri-widget--button esri-interactive';
      legendToggleBtn.innerHTML = '<span class="esri-icon-layer-list" title="Mostrar/Ocultar Leyenda"></span>';
      legendToggleBtn.style.margin = '5px';

      legendToggleBtn.onclick = () => {
        const isVisible = this.legendContainer.style.display !== 'none';
        this.legendContainer.style.display = isVisible ? 'none' : 'block';
      };

      this.mapView.ui.add(legendToggleBtn, 'top-right');
      
      
      this.featureServerAlerts =  new FeatureLayer({
        url: "https://gis.bosques.gob.pe/server/rest/services/Geobosques/serv_geobosques_alertas_tempranas_areas_edit/FeatureServer/0"
      });


      this.sketsch = new Sketch({
      view: this.mapView,
      layer: this.resultsLayer,
      creationMode: 'single',
      availableCreateTools: ['polygon', 'rectangle'], // Solo estos
      visibleElements: {
        createTools: {
          point: false,
          polyline: false,
          circle: false,                    
          polygon: true,
          rectangle: true
        },
        selectionTools: {
          "lasso-selection": false,   // Desactiva selección lasso
          "rectangle-selection": false //  Desactiva selección rectangular
        },
        undoRedoMenu: true,
        settingsMenu: false, //  Opcional: oculta engranaje de configuración
        duplicateButton: true //  Dejar duplicar
        //deleteButton: true     //  Dejar eliminar
      }
    });

      this.mapView.ui.add(this.sketsch, "top-right");
      this.sketsch.visible = false;

      this.sketsch.on('create', (event) => {
        if (event.state === 'complete') {
          const geometry = event.graphic.geometry;          
          console.log('Geometría capturada:', geometry);
          if (geometry.type === 'polygon'){
            // Llamar a la función que guarda en el FeatureServer
            alert("hola grabara");
            this.enviarAGuardar(geometry as Polygon);
          }          
        }
      });      

      console.log("Mapa inicializado");
      return Promise.resolve("Mapa cargado con éxito 2.0");

    } catch (error) {
      console.error("Error al cargar el mapa: ", error);
      return Promise.reject("Error al cargar el mapa");
    }
  }


  async enviarAGuardar(geometry: Polygon) {

      //alert("ply end");

      const attributes = {
        descripcion: 'Área de prueba Roberto 2025',
        id_usuario: 1,
        estado: 1,
        fe_registro: Date.now(),
        nro_alerta_sem: 123,
        tipo_carga: 2,
        id_persona: 999,
        id_area: 10
      };

      const graphic = new Graphic({
        geometry: geometry,
        attributes: attributes
      });

      try {


        if (this.featureServerAlerts) {
          
          const result = await this.featureServerAlerts.applyEdits({
            addFeatures: [graphic]
          });

          if (result.addFeatureResults.length && !result.addFeatureResults[0].error) {
            console.log('Feature agregado correctamente', result.addFeatureResults[0]);
          } else {
            console.error('Error al agregar feature', result.addFeatureResults[0].error);
          }

        }else{
          console.error('FeatureLayer no está inicializado.');

        }


      } catch (error) {
        console.error('Error en applyEdits:', error);
      }


  }




  iniciaDibujoPersonal (): void{

    if (this.sketsch){
      this.sketsch.visible = true;
    }

  }



  finDibujoPersonal (): void{

    if (this.sketsch){
      this.sketsch.visible = false;
    }

    

  }

  
  
  




  async queryByDistrito(ubigeo: string): Promise<void> {
    const url = "https://gis.bosques.gob.pe/server/rest/services/Geobosques/serv_geobosques_bosque_perdida/MapServer/2";
    const whereClause = `ubigeo = '${ubigeo}'`;
    const features = await this.queryFeatureLayer(url, whereClause);

    this.addResultsToMap(features);
  }

  async queryByProvincia(ubigeo: string): Promise<void> {
    const url = "https://gis.bosques.gob.pe/server/rest/services/Geobosques/serv_geobosques_bosque_perdida/MapServer/1";
    const whereClause = `ubigeo_prov = '${ubigeo}'`;
    const features = await this.queryFeatureLayer(url, whereClause);

    this.addResultsToMap(features);
  }

  async queryByDepartamento(ubigeo: string): Promise<void> {
    const url = "https://gis.bosques.gob.pe/server/rest/services/Geobosques/serv_geobosques_bosque_perdida/MapServer/0";
    const whereClause = `coddep = '${ubigeo}'`;
    const features = await this.queryFeatureLayer(url, whereClause);

    this.addResultsToMap(features);
  }

  private addResultsToMap(features: __esri.Graphic[]): void {
    if (!this.resultsLayer) {
      console.error("No se encontró la capa de resultados.");
      return;
    }
  
    this.resultsLayer.removeAll(); // Limpia los resultados anteriores
  
    // Define el símbolo utilizando SimpleFillSymbol
    const symbol = new SimpleFillSymbol({
      color: [0, 255, 255, 0], // Fondo semitransparente (marrón claro con opacidad 30%)
      outline: {
        color: [0, 255, 255], // Borde más luminoso (naranja claro con opacidad 80%)
        width: 3, // Ancho del borde
      },
    });
  
    // Asigna el símbolo a cada gráfico
    const updatedFeatures = features.map((feature) => {
      feature.symbol = symbol; // Asigna el símbolo creado
      return feature;
    });
  
    this.resultsLayer.addMany(updatedFeatures); // Agrega las nuevas geometrías al mapa
  
    if (features.length > 0 && this.mapView) {
      this.mapView.goTo(features); // Ajusta la vista al área de los resultados
    }
  }

  async queryFeatureLayer(layerUrl: string, whereClause: string) {
    const featureLayer = new FeatureLayer({
      url: layerUrl,
    });
  
    const query = featureLayer.createQuery();
    query.where = whereClause;
    query.outFields = ["*"];
    query.returnGeometry = true;
  
    try {
      const response = await featureLayer.queryFeatures(query);
      //console.log("Consulta exitosa:", response.features);
      return response.features;
    } catch (error) {
      console.error("Error en la consulta:", error);
      throw error;
    }
  }

  zoomIn(): void {
    if (this.mapView) {
      this.mapView.zoom += 1;
      console.log("Zoom aumentado");
    } else {
      console.error("El mapa no ha sido inicializado aún.");
    }
  }

  /**
   * Limpia y destruye la vista del mapa para liberar recursos.
   */
  destruir(): void {
    if (this.mapView) {
      this.mapView.destroy();
      this.mapView = null;
      console.log("Mapa destruido");
    }
  }
}




export class MapaCambioUso {
  private mapView: MapView | null = null;
  private divId: string;
  private resultsLayer: GraphicsLayer | null = null;
  private simpleFillSymbol: SimpleFillSymbol | null = null;
  private capaMapServer: MapImageLayer | null = null;
  private rasterUCUS: MapImageLayer | null = null;
  private arrcatalogoLayer: any[] = [];
  private legendContainer!: HTMLDivElement;

  constructor(divId: string) {
    this.divId = divId;
    this.resultsLayer = new GraphicsLayer();


  }


  async iniciar(): Promise<string> {
    try {
      this.capaMapServer = new MapImageLayer({
        url: "https://gis.bosques.gob.pe/server/rest/services/Geobosques/serv_geobosques_bosque_perdida/MapServer",
      });
      this.rasterUCUS= new MapImageLayer({
        url: "https://gis.bosques.gob.pe/server/rest/services/Geobosques/serv_geobosques_uso_cambio_uso_raster/MapServer",
      });

      const map = new Map({
        basemap: "hybrid",
        layers: [this.rasterUCUS, this.resultsLayer!],
      });

      this.mapView = new MapView({
        container: this.divId,
        map: map,
        center: [-75.015, -9.19],
        zoom: 4,
      });

      this.legendContainer = document.createElement('div');
      this.legendContainer.classList.add('esri-widget', 'esri-widget--panel');
      this.legendContainer.style.width = '250px';
      this.legendContainer.style.display = 'none'; // Oculta al inicio

      const legend = new Legend({
        view: this.mapView ,  // Asociamos el widget de leyenda con la vista del mapa
        container: this.legendContainer
      });

      this.mapView.ui.add(this.legendContainer, 'bottom-right');  // 'top-left' coloca la leyenda en la parte superior izquierda del mapa
      
      const legendToggleBtn = document.createElement('div');
      legendToggleBtn.className = 'esri-widget esri-widget--button esri-interactive';
      legendToggleBtn.innerHTML = '<span class="esri-icon-layer-list" title="Mostrar/Ocultar Leyenda"></span>';
      legendToggleBtn.style.margin = '5px';

      legendToggleBtn.onclick = () => {
        const isVisible = this.legendContainer.style.display !== 'none';
        this.legendContainer.style.display = isVisible ? 'none' : 'block';
      };

      this.mapView.ui.add(legendToggleBtn, 'top-right');

      console.log("Mapa USCUS inicializado");
      return Promise.resolve("Mapa cargado con éxito 2.0");

    } catch (error) {
      console.error("Error al cargar el mapa: ", error);
      return Promise.reject("Error al cargar el mapa");
    }
  }

  resetZoom(): void {
    if (this.mapView) {  // Comprobamos si mapView no es null ni undefined
        this.mapView.goTo({
            center: [-75.015, -9.19],  // Centro inicial
            zoom: 4                    // Nivel de zoom inicial
        });
    } else {
        console.error("mapView no está definido");
    }
  }


  async queryByDistrito(ubigeo: string): Promise<void> {
    const url = "https://gis.bosques.gob.pe/server/rest/services/Geobosques/serv_geobosques_bosque_perdida/MapServer/2";
    const whereClause = `ubigeo = '${ubigeo}'`;
    const features = await this.queryFeatureLayer(url, whereClause);

    this.addResultsToMap(features);
  }

  async queryByProvincia(ubigeo: string): Promise<void> {
    const url = "https://gis.bosques.gob.pe/server/rest/services/Geobosques/serv_geobosques_bosque_perdida/MapServer/1";
    const whereClause = `ubigeo_prov = '${ubigeo}'`;
    const features = await this.queryFeatureLayer(url, whereClause);

    this.addResultsToMap(features);
  }

  async queryByDepartamento(ubigeo: string): Promise<void> {
    const url = "https://gis.bosques.gob.pe/server/rest/services/Geobosques/serv_geobosques_bosque_perdida/MapServer/0";
    const whereClause = `coddep = '${ubigeo}'`;
    const features = await this.queryFeatureLayer(url, whereClause);

    this.addResultsToMap(features);
  }

  private addResultsToMap(features: __esri.Graphic[]): void {
    if (!this.resultsLayer) {
      console.error("No se encontró la capa de resultados.");
      return;
    }
  
    this.resultsLayer.removeAll(); // Limpia los resultados anteriores
  
    // Define el símbolo utilizando SimpleFillSymbol
    const symbol = new SimpleFillSymbol({
      color: [0, 255, 255, 0], // Fondo semitransparente (marrón claro con opacidad 30%)
      outline: {
        color: [0, 255, 255], // Borde más luminoso (naranja claro con opacidad 80%)
        width: 3, // Ancho del borde
      },
    });
  
    // Asigna el símbolo a cada gráfico
    const updatedFeatures = features.map((feature) => {
      feature.symbol = symbol; // Asigna el símbolo creado
      return feature;
    });
  
    this.resultsLayer.addMany(updatedFeatures); // Agrega las nuevas geometrías al mapa
  
    if (features.length > 0 && this.mapView) {
      this.mapView.goTo(features); // Ajusta la vista al área de los resultados
    }
  }

  async queryFeatureLayer(layerUrl: string, whereClause: string) {
    const featureLayer = new FeatureLayer({
      url: layerUrl,
    });
  
    const query = featureLayer.createQuery();
    query.where = whereClause;
    query.outFields = ["*"];
    query.returnGeometry = true;
  
    try {
      const response = await featureLayer.queryFeatures(query);
      //console.log("Consulta exitosa:", response.features);
      return response.features;
    } catch (error) {
      console.error("Error en la consulta:", error);
      throw error;
    }
  }

  zoomIn(): void {
    if (this.mapView) {
      this.mapView.zoom += 1;
      console.log("Zoom aumentado");
    } else {
      console.error("El mapa no ha sido inicializado aún.");
    }
  }

  /**
   * Limpia y destruye la vista del mapa para liberar recursos.
   */
  destruir(): void {
    if (this.mapView) {
      this.mapView.destroy();
      this.mapView = null;
      console.log("Mapa destruido");
    }
  }
}
